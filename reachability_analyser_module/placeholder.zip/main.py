import boto3
import time
import os

path_ids_string = os.environ.get("REACHABILITY_PATH_IDS")
sns_topic_arn = os.environ.get("SNS_TOPIC_ARN")

path_ids = path_ids_string.split(",")

def handler(event, context):
    ec2_client = boto3.client('ec2')
    sns_client = boto3.client('sns')
    
    for path_id in path_ids:
        try:
            analysis_response = ec2_client.start_network_insights_analysis(NetworkInsightsPathId=path_id)
            analysis_id = analysis_response['NetworkInsightsAnalysis']['NetworkInsightsAnalysisId']
            print(f"Started network insights analysis with ID: {analysis_id}")
            
            max_wait_time = 300
            poll_interval = 5
            elapsed_time = 0

            while elapsed_time < max_wait_time:
                analysis_status_response = ec2_client.describe_network_insights_analyses(
                    NetworkInsightsAnalysisIds=[analysis_id]
                )
                analysis_status = analysis_status_response['NetworkInsightsAnalyses'][0]['Status']
                print(f"Current analysis status: {analysis_status}")
                
                if analysis_status in ['succeeded', 'failed']:
                    break
                
                time.sleep(poll_interval)
                elapsed_time += poll_interval
            
            if elapsed_time >= max_wait_time:
                print("Analysis timed out.")
                continue
            
            if analysis_status == 'succeeded':
                analysis_result_response = ec2_client.describe_network_insights_analyses(
                    NetworkInsightsAnalysisIds=[analysis_id]
                )
                analysis_result = analysis_result_response['NetworkInsightsAnalyses'][0]
                explanations = analysis_result.get('Explanations', [])
                
                if not explanations:
                    print("Network is reachable.")
                else:
                    print("Network is not reachable. Explanations:")
                    for explanation in explanations:
                        print(explanation)
                    
                    sns_message = "Network is not reachable. Explanations:\n" + "\n".join(str(explanation) for explanation in explanations)
                    sns_response = sns_client.publish(
                        TopicArn=sns_topic_arn,
                        Message=sns_message,
                        Subject="Network Insights Analysis Result: Network Not Reachable"
                    )
                    print(f"SNS message sent with response: {sns_response}")
            else:
                print("Network analysis failed.")
            
            response = ec2_client.describe_network_insights_paths(
                NetworkInsightsPathIds=[path_id]
            )
            print(response)
        
        except Exception as e:
            print(f"An error occurred: {str(e)}")
